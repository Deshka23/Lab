myApp.controller("page2Controller", 
	function page2Controller($scope) {
	$scope.attr = [{
		name: "Object2.1",
		value: "Value2.1"
	}, {
		name: "Object2.2",
		value: "Value2.2"
	}];
});
