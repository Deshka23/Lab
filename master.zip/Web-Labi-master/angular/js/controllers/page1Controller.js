myApp.controller("page1Controller", 
	function page1Controller($scope) {
		$scope.attr = [{
			name: "Object1.1",
			value: "Value1.1"
		},{
			name: "Object1.2",
			value: "Value1.2"
			}
		];
});
